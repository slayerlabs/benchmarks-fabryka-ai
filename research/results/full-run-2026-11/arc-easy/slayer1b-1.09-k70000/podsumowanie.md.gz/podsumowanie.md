| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T51 | space | 2376 | 0.662 ±0.010 | 0.622 ±0.010 | 0.554 ±0.010 | 0.963 ±0.010 | 0.250 | 0.266 | 0.31 |
