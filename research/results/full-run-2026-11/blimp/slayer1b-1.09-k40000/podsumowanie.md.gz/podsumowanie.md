| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T01 | space | 67000 | 0.815 ±0.021 | 0.764 ±0.026 | — | 2.273 ±0.030 | 0.500 | — | 0.81 |
