| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T03 | space | 62 | byte_ppl 1.714 ±0.015 | word_ppl 17.847 ±0.733 | | BPB 0.777 ±0.012 | | | |
