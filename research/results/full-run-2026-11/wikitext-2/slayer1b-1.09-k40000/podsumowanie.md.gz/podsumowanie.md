| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T03 | space | 62 | byte_ppl 1.702 ±0.016 | word_ppl 17.198 ±0.760 | | BPB 0.767 ±0.013 | | | |
