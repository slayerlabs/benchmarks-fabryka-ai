| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T07 | space | 1267 | 0.574 ±0.013 | 0.574 ±0.013 | — | 1.216 ±0.027 | 0.500 | 0.504 | 0.50 |
