| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T04 | space | 3272 | 0.986 ±0.002 | 0.969 ±0.003 | — | 1.497 ±0.009 | 0.500 | — | 0.99 |
