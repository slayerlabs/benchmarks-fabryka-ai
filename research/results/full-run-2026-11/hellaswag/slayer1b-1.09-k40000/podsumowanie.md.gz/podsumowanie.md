| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T05 | space | 10042 | 0.417 ±0.005 | 0.528 ±0.005 | 0.457 ±0.005 | 0.834 ±0.002 | 0.250 | 0.257 | 0.25 |
