| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T44 | space | 500 | 0.552 ±0.022 | 0.524 ±0.022 | 0.552 ±0.022 | 2.927 ±0.038 | 0.333 | 0.552 | 0.95 |
