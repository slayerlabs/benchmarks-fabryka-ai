| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T44 | space | 500 | 0.562 ±0.022 | 0.330 ±0.021 | 0.602 ±0.022 | 3.647 ±0.033 | 0.333 | 0.552 | 0.57 |
