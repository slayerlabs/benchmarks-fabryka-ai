| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T06 | space | 1838 | 0.705 ±0.011 | 0.712 ±0.011 | 0.628 ±0.011 | 1.117 ±0.012 | 0.500 | 0.505 | 0.51 |
