| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T06 | space | 1838 | 0.727 ±0.010 | 0.727 ±0.010 | 0.624 ±0.011 | 1.094 ±0.013 | 0.500 | 0.505 | 0.51 |
