| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T06 | space | 1838 | 0.682 ±0.011 | 0.662 ±0.011 | 0.576 ±0.012 | 1.217 ±0.012 | 0.500 | 0.505 | 0.50 |
