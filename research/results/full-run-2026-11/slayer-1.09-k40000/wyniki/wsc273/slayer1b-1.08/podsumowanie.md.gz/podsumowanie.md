| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T14 | space | 273 | 0.615 ±0.022 | 0.615 ±0.022 | — | 2.275 ±0.127 | 0.500 | 0.502 | 0.52 |
