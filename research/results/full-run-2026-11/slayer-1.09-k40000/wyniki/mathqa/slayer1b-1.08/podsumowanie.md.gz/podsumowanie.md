| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T19 | space | 2985 | 0.234 ±0.008 | 0.228 ±0.008 | 0.246 ±0.008 | 3.302 ±0.018 | 0.200 | 0.226 | 0.24 |
