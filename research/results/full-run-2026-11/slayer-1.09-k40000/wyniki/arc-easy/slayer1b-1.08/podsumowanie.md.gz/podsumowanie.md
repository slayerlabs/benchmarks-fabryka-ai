| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T51 | space | 2376 | 0.584 ±0.010 | 0.519 ±0.010 | 0.484 ±0.010 | 1.303 ±0.014 | 0.250 | 0.266 | 0.33 |
