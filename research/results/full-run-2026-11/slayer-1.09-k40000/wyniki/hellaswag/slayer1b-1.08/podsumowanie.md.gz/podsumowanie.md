| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T05 | space | 10042 | 0.351 ±0.005 | 0.434 ±0.005 | 0.388 ±0.005 | 0.898 ±0.002 | 0.250 | 0.257 | 0.25 |
