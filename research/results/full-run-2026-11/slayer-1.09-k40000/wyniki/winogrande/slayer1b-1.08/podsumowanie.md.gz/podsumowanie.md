| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T07 | space | 1267 | 0.537 ±0.013 | 0.537 ±0.013 | — | 1.267 ±0.026 | 0.500 | 0.504 | 0.50 |
