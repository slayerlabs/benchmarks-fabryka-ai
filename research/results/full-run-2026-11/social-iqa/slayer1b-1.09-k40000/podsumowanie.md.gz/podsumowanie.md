| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T46 | space | 1954 | 0.409 ±0.011 | 0.434 ±0.011 | 0.411 ±0.011 | 1.746 ±0.016 | 0.333 | 0.336 | 0.34 |
