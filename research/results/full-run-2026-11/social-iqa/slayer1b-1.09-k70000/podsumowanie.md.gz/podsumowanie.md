| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T46 | space | 1954 | 0.418 ±0.011 | 0.439 ±0.011 | 0.406 ±0.011 | 1.706 ±0.016 | 0.333 | 0.336 | 0.34 |
