| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T19 | space | 2985 | 0.233 ±0.008 | 0.225 ±0.008 | 0.247 ±0.008 | 2.747 ±0.016 | 0.200 | 0.226 | 0.24 |
