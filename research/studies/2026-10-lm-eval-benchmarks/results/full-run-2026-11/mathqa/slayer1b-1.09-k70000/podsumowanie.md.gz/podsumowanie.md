| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T19 | space | 2985 | 0.225 ±0.008 | 0.220 ±0.008 | 0.254 ±0.008 | 2.925 ±0.017 | 0.200 | 0.226 | 0.24 |
