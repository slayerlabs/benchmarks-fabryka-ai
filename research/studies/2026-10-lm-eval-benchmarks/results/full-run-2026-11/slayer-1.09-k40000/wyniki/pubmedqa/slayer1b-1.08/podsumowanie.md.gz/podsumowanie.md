| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T44 | space | 500 | 0.434 ±0.022 | 0.232 ±0.019 | 0.478 ±0.022 | 3.686 ±0.026 | 0.333 | 0.552 | 0.73 |
