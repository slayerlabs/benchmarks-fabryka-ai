| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T46 | space | 1954 | 0.397 ±0.011 | 0.430 ±0.011 | 0.389 ±0.011 | 1.862 ±0.018 | 0.333 | 0.336 | 0.33 |
