| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T04 | space | 3272 | 0.987 ±0.002 | 0.976 ±0.003 | — | 1.463 ±0.008 | 0.500 | — | 0.99 |
