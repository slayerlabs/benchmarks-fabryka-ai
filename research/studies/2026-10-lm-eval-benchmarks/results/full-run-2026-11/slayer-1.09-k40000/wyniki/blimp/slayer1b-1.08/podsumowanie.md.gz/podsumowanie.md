| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T01 | space | 67000 | 0.805 ±0.021 | 0.748 ±0.026 | — | 2.304 ±0.032 | 0.500 | — | 0.80 |
