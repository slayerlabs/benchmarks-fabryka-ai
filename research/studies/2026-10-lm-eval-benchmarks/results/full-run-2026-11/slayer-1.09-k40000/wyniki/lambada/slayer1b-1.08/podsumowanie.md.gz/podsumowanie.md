| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T17 | space | 5153 | acc 0.401 ±0.007 | | | | 0.000 | 0.003 | — |
