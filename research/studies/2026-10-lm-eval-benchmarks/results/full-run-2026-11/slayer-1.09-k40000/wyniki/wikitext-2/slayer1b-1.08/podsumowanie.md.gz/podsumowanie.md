| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T03 | space | 62 | byte_ppl 1.780 ±0.015 | word_ppl 21.847 ±0.883 | | BPB 0.832 ±0.012 | | | |
