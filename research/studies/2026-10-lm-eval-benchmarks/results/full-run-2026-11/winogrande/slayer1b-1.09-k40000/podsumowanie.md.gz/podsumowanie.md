| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T07 | space | 1267 | 0.577 ±0.013 | 0.577 ±0.013 | — | 1.217 ±0.027 | 0.500 | 0.504 | 0.50 |
