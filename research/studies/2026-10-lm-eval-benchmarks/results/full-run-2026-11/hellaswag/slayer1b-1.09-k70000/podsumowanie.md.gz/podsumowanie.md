| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T05 | space | 10042 | 0.428 ±0.005 | 0.553 ±0.005 | 0.466 ±0.005 | 0.827 ±0.002 | 0.250 | 0.257 | 0.25 |
