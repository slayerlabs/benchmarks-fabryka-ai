| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T51 | space | 2376 | 0.666 ±0.010 | 0.617 ±0.010 | 0.560 ±0.010 | 1.046 ±0.012 | 0.250 | 0.266 | 0.32 |
