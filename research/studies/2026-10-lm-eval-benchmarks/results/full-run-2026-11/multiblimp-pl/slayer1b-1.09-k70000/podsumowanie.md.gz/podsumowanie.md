| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T04 | space | 3272 | 0.982 ±0.002 | 0.967 ±0.003 | — | 1.504 ±0.009 | 0.500 | — | 0.98 |
