| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T14 | space | 273 | 0.637 ±0.024 | 0.637 ±0.024 | — | 2.565 ±0.155 | 0.500 | 0.502 | 0.51 |
