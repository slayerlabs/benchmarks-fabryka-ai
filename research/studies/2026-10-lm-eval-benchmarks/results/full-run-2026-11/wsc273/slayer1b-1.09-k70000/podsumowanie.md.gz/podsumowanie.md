| zadanie | wariant | n | acc | acc_norm | acc_pmi | BPB poprawnej | losowa | większ. | najczęstsza pred. |
|---|---|---|---|---|---|---|---|---|---|
| T14 | space | 273 | 0.637 ±0.023 | 0.637 ±0.023 | — | 2.618 ±0.155 | 0.500 | 0.502 | 0.51 |
